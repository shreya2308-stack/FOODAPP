<?php
$server = "localhost";
$user = "root";
$password = "";
$db = "cart_system";

$con = mysqli_connect($server,$user,$password,$db);

?>
